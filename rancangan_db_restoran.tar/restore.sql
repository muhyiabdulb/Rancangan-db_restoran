--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_user DROP CONSTRAINT tb_user_pkey;
ALTER TABLE ONLY public.tb_order DROP CONSTRAINT tb_order_pkey;
ALTER TABLE ONLY public.tb_masakan DROP CONSTRAINT tb_masakan_pkey;
ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.tb_detail_order DROP CONSTRAINT tb_detail_order_pkey;
ALTER TABLE public.transaksi ALTER COLUMN id_order DROP DEFAULT;
ALTER TABLE public.transaksi ALTER COLUMN id_user DROP DEFAULT;
ALTER TABLE public.transaksi ALTER COLUMN id_transaksi DROP DEFAULT;
ALTER TABLE public.tb_user ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.tb_user ALTER COLUMN id_user DROP DEFAULT;
ALTER TABLE public.tb_order ALTER COLUMN id_user DROP DEFAULT;
ALTER TABLE public.tb_order ALTER COLUMN id_order DROP DEFAULT;
ALTER TABLE public.tb_masakan ALTER COLUMN id_masakan DROP DEFAULT;
ALTER TABLE public.tb_level ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.tb_detail_order ALTER COLUMN id_masakan DROP DEFAULT;
ALTER TABLE public.tb_detail_order ALTER COLUMN id_order DROP DEFAULT;
ALTER TABLE public.tb_detail_order ALTER COLUMN id_detail_order DROP DEFAULT;
DROP SEQUENCE public.transaksi_id_user_seq;
DROP SEQUENCE public.transaksi_id_transaksi_seq;
DROP SEQUENCE public.transaksi_id_order_seq;
DROP TABLE public.transaksi;
DROP SEQUENCE public.tb_user_id_user_seq;
DROP SEQUENCE public.tb_user_id_level_seq;
DROP TABLE public.tb_user;
DROP SEQUENCE public.tb_order_id_user_seq;
DROP SEQUENCE public.tb_order_id_order_seq;
DROP TABLE public.tb_order;
DROP SEQUENCE public.tb_masakan_id_masakan_seq;
DROP TABLE public.tb_masakan;
DROP SEQUENCE public.tb_level_id_level_seq;
DROP TABLE public.tb_level;
DROP SEQUENCE public.tb_detail_order_id_order_seq;
DROP SEQUENCE public.tb_detail_order_id_masakan_seq;
DROP SEQUENCE public.tb_detail_order_id_detail_order_seq;
DROP TABLE public.tb_detail_order;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tb_detail_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_detail_order (
    id_detail_order integer NOT NULL,
    id_order integer NOT NULL,
    id_masakan integer NOT NULL,
    keterangan text,
    status_detail_order character varying
);


ALTER TABLE tb_detail_order OWNER TO postgres;

--
-- Name: tb_detail_order_id_detail_order_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_detail_order_id_detail_order_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_detail_order_id_detail_order_seq OWNER TO postgres;

--
-- Name: tb_detail_order_id_detail_order_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_detail_order_id_detail_order_seq OWNED BY tb_detail_order.id_detail_order;


--
-- Name: tb_detail_order_id_masakan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_detail_order_id_masakan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_detail_order_id_masakan_seq OWNER TO postgres;

--
-- Name: tb_detail_order_id_masakan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_detail_order_id_masakan_seq OWNED BY tb_detail_order.id_masakan;


--
-- Name: tb_detail_order_id_order_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_detail_order_id_order_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_detail_order_id_order_seq OWNER TO postgres;

--
-- Name: tb_detail_order_id_order_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_detail_order_id_order_seq OWNED BY tb_detail_order.id_order;


--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level integer NOT NULL,
    nama_level character varying
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_level_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_level_id_level_seq OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_level_id_level_seq OWNED BY tb_level.id_level;


--
-- Name: tb_masakan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_masakan (
    id_masakan integer NOT NULL,
    nama_masakan character varying,
    harga integer,
    status_masakan character varying
);


ALTER TABLE tb_masakan OWNER TO postgres;

--
-- Name: tb_masakan_id_masakan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_masakan_id_masakan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_masakan_id_masakan_seq OWNER TO postgres;

--
-- Name: tb_masakan_id_masakan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_masakan_id_masakan_seq OWNED BY tb_masakan.id_masakan;


--
-- Name: tb_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_order (
    id_order integer NOT NULL,
    no_meja integer,
    tanggal date,
    id_user integer NOT NULL,
    keterangan text,
    status_order character varying
);


ALTER TABLE tb_order OWNER TO postgres;

--
-- Name: tb_order_id_order_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_order_id_order_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_order_id_order_seq OWNER TO postgres;

--
-- Name: tb_order_id_order_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_order_id_order_seq OWNED BY tb_order.id_order;


--
-- Name: tb_order_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_order_id_user_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_order_id_user_seq OWNER TO postgres;

--
-- Name: tb_order_id_user_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_order_id_user_seq OWNED BY tb_order.id_user;


--
-- Name: tb_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_user (
    id_user integer NOT NULL,
    username character varying,
    password character varying,
    nama_user character varying,
    id_level integer NOT NULL
);


ALTER TABLE tb_user OWNER TO postgres;

--
-- Name: tb_user_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_user_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_user_id_level_seq OWNER TO postgres;

--
-- Name: tb_user_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_user_id_level_seq OWNED BY tb_user.id_level;


--
-- Name: tb_user_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_user_id_user_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_user_id_user_seq OWNER TO postgres;

--
-- Name: tb_user_id_user_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_user_id_user_seq OWNED BY tb_user.id_user;


--
-- Name: transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE transaksi (
    id_transaksi integer NOT NULL,
    id_user integer NOT NULL,
    id_order integer NOT NULL,
    tanggal date,
    total_bayar integer
);


ALTER TABLE transaksi OWNER TO postgres;

--
-- Name: transaksi_id_order_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE transaksi_id_order_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE transaksi_id_order_seq OWNER TO postgres;

--
-- Name: transaksi_id_order_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE transaksi_id_order_seq OWNED BY transaksi.id_order;


--
-- Name: transaksi_id_transaksi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE transaksi_id_transaksi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE transaksi_id_transaksi_seq OWNER TO postgres;

--
-- Name: transaksi_id_transaksi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE transaksi_id_transaksi_seq OWNED BY transaksi.id_transaksi;


--
-- Name: transaksi_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE transaksi_id_user_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE transaksi_id_user_seq OWNER TO postgres;

--
-- Name: transaksi_id_user_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE transaksi_id_user_seq OWNED BY transaksi.id_user;


--
-- Name: tb_detail_order id_detail_order; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_detail_order ALTER COLUMN id_detail_order SET DEFAULT nextval('tb_detail_order_id_detail_order_seq'::regclass);


--
-- Name: tb_detail_order id_order; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_detail_order ALTER COLUMN id_order SET DEFAULT nextval('tb_detail_order_id_order_seq'::regclass);


--
-- Name: tb_detail_order id_masakan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_detail_order ALTER COLUMN id_masakan SET DEFAULT nextval('tb_detail_order_id_masakan_seq'::regclass);


--
-- Name: tb_level id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level ALTER COLUMN id_level SET DEFAULT nextval('tb_level_id_level_seq'::regclass);


--
-- Name: tb_masakan id_masakan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_masakan ALTER COLUMN id_masakan SET DEFAULT nextval('tb_masakan_id_masakan_seq'::regclass);


--
-- Name: tb_order id_order; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_order ALTER COLUMN id_order SET DEFAULT nextval('tb_order_id_order_seq'::regclass);


--
-- Name: tb_order id_user; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_order ALTER COLUMN id_user SET DEFAULT nextval('tb_order_id_user_seq'::regclass);


--
-- Name: tb_user id_user; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_user ALTER COLUMN id_user SET DEFAULT nextval('tb_user_id_user_seq'::regclass);


--
-- Name: tb_user id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_user ALTER COLUMN id_level SET DEFAULT nextval('tb_user_id_level_seq'::regclass);


--
-- Name: transaksi id_transaksi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY transaksi ALTER COLUMN id_transaksi SET DEFAULT nextval('transaksi_id_transaksi_seq'::regclass);


--
-- Name: transaksi id_user; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY transaksi ALTER COLUMN id_user SET DEFAULT nextval('transaksi_id_user_seq'::regclass);


--
-- Name: transaksi id_order; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY transaksi ALTER COLUMN id_order SET DEFAULT nextval('transaksi_id_order_seq'::regclass);


--
-- Data for Name: tb_detail_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM stdin;
\.
COPY tb_detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM '$$PATH$$/2875.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2868.dat';

--
-- Data for Name: tb_masakan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_masakan (id_masakan, nama_masakan, harga, status_masakan) FROM stdin;
\.
COPY tb_masakan (id_masakan, nama_masakan, harga, status_masakan) FROM '$$PATH$$/2877.dat';

--
-- Data for Name: tb_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_order (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM stdin;
\.
COPY tb_order (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM '$$PATH$$/2871.dat';

--
-- Data for Name: tb_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_user (id_user, username, password, nama_user, id_level) FROM stdin;
\.
COPY tb_user (id_user, username, password, nama_user, id_level) FROM '$$PATH$$/2866.dat';

--
-- Data for Name: transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM stdin;
\.
COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM '$$PATH$$/2863.dat';

--
-- Name: tb_detail_order_id_detail_order_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_detail_order_id_detail_order_seq', 1, false);


--
-- Name: tb_detail_order_id_masakan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_detail_order_id_masakan_seq', 1, false);


--
-- Name: tb_detail_order_id_order_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_detail_order_id_order_seq', 1, false);


--
-- Name: tb_level_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_level_id_level_seq', 1, false);


--
-- Name: tb_masakan_id_masakan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_masakan_id_masakan_seq', 1, false);


--
-- Name: tb_order_id_order_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_order_id_order_seq', 1, false);


--
-- Name: tb_order_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_order_id_user_seq', 1, false);


--
-- Name: tb_user_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_user_id_level_seq', 1, false);


--
-- Name: tb_user_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_user_id_user_seq', 1, false);


--
-- Name: transaksi_id_order_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('transaksi_id_order_seq', 1, false);


--
-- Name: transaksi_id_transaksi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('transaksi_id_transaksi_seq', 1, false);


--
-- Name: transaksi_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('transaksi_id_user_seq', 1, false);


--
-- Name: tb_detail_order tb_detail_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_detail_order
    ADD CONSTRAINT tb_detail_order_pkey PRIMARY KEY (id_detail_order);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- Name: tb_masakan tb_masakan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_masakan
    ADD CONSTRAINT tb_masakan_pkey PRIMARY KEY (id_masakan);


--
-- Name: tb_order tb_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_order
    ADD CONSTRAINT tb_order_pkey PRIMARY KEY (id_order);


--
-- Name: tb_user tb_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_user
    ADD CONSTRAINT tb_user_pkey PRIMARY KEY (id_user);


--
-- PostgreSQL database dump complete
--

